var searchData=
[
  ['optional',['Optional',['../class_mad_level_manager_1_1_backend_1_1_optional.html',1,'MadLevelManager::Backend']]]
];
