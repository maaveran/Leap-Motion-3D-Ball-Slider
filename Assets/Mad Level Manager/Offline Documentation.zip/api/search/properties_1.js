var searchData=
[
  ['current',['current',['../class_mad_level_manager_1_1_mad_level_layout.html#abfe2fae7d024a36c28f7d1ab6ea95f0b',1,'MadLevelManager::MadLevelLayout']]],
  ['currentlevelname',['currentLevelName',['../class_mad_level_manager_1_1_mad_level.html#a1dc835c37cec98a1fa7c8438fd84d8d9',1,'MadLevelManager::MadLevel']]]
];
